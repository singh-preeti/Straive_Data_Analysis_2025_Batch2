import pandas as pd
import joblib
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import RandomForestRegressor
import os

MODEL_PATH = "sales_model.pkl"
DATASET = "Diwali Sales Data (1).csv"

df = None
model = None
encoders = {}

def load_dataset():
    global df
    df = pd.read_csv(DATASET)
    df.fillna(0, inplace=True)
    return df

def train_model(handler):
    global df, model, encoders
    df = load_dataset()
    target = "Amount"
    drop_cols = ["User_ID", "Cust_name", "Status", "unnamed1"]
    df = df.drop(columns=[c for c in drop_cols if c in df.columns], errors="ignore")
    encoders = {}
    for col in df.select_dtypes(include="object").columns:
        le = LabelEncoder()
        df[col] = le.fit_transform(df[col])
        encoders[col] = le
    X = df.drop(columns=[target])
    y = df[target]
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    model = RandomForestRegressor(n_estimators=200, random_state=42)
    model.fit(X_train, y_train)
    joblib.dump((model, encoders, list(X.columns)), MODEL_PATH)
    return {"message": "Model trained", "rows": len(df), "features": list(X.columns)}

def predict_sales(handler):
    global model, encoders
    if model is None and os.path.exists(MODEL_PATH):
        model, encoders, feats = joblib.load(MODEL_PATH)
    data = handler.get_json()
    X = pd.DataFrame([data])
    for col, le in encoders.items():
        if col in X:
            X[col] = le.transform([X[col].iloc[0]])
    pred = float(model.predict(X)[0])
    return {"predicted_sales_amount": pred}

def sample_data(handler):
    df = load_dataset()
    return df.head(10).to_dict(orient="records")
