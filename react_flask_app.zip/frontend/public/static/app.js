const e = React.createElement;
const {useState, useEffect} = React;

function App() {
  const [message, setMessage] = useState('loading...');
  const [echoInput, setEchoInput] = useState('');
  const [echoResult, setEchoResult] = useState(null);

  useEffect(() => {
    fetch('/api/hello')
      .then(res => res.json())
      .then(data => setMessage(data.message))
      .catch(err => setMessage('Could not reach backend: ' + err.message));
  }, []);

  const sendEcho = async () => {
    const res = await fetch('/api/echo', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({text: echoInput})
    });
    const data = await res.json();
    setEchoResult(data);
  };

  return e('div', null,
    e('h1', null, 'React + Flask (Dockerized)'),
    e('p', null, 'Backend message: ' + message),
    e('input', {value: echoInput, onChange:(ev)=>setEchoInput(ev.target.value)}),
    e('button', {onClick:sendEcho}, 'Send'),
    e('pre', null, echoResult ? JSON.stringify(echoResult, null, 2) : '')
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(React.createElement(App));
