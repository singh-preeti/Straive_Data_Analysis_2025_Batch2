# udemy_cart.py

class Cart:
    """Simple Udemy-style cart for adding and calculating total course price."""

    def __init__(self):
        self.courses = []

    def add_course(self, course_name, price):
        self.courses.append({"name": course_name, "price": price})

    def total_price(self):
        return sum(c["price"] for c in self.courses)
