import pytest
from udemy_cart import Cart

# -----------------------------
# FIXTURE EXAMPLE
# -----------------------------
@pytest.fixture
def sample_cart():
    """Creates a fresh cart with two courses already added."""
    cart = Cart()
    cart.add_course("Python Basics", 500)
    cart.add_course("AI Fundamentals", 700)
    return cart


# -----------------------------
# TEST CASES USING FIXTURE
# -----------------------------

def test_cart_initial_total(sample_cart):
    """Uses fixture to test starting total price."""
    assert sample_cart.total_price() == 1200


def test_add_new_course(sample_cart):
    """Add another course using cart from fixture."""
    sample_cart.add_course("Django Mastery", 800)
    assert sample_cart.total_price() == 2000


def test_cart_is_isolated(sample_cart):
    """
    Each test gets a fresh fixture so previous test additions won't carry over.
    """
    assert sample_cart.total_price() == 1200  # remains unchanged

# ✔ sample_cart() runs before each test, providing a CLEAN cart
# ✔ Tests do not affect each other
# ✔ Reusable setup logic
# ✔ Very similar to what QA engineers use for real projects