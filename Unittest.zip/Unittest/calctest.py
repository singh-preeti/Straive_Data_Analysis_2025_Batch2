import unittest
import calc



class TestCalculator2(unittest.TestCase):
    def test_add(self):
        self.assertEqual(calc.add(10, 20), 3)
        self.assertEqual(calc.add(-10, 20), 30)
        self.assertEqual(calc.add(-10, -20), 30)
        self.assertEqual(calc.add(0, 0), 30)

    def test_mult(self):
        self.assertEqual(calc.multiply(10, 5), 20)


