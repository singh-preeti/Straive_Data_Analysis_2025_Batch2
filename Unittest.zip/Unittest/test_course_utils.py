# test_course_utils.py

import pytest
from course_utils import calculate_discounted_price, is_course_full, get_course_level

# -------------------------------
# Tests for calculate_discounted_price
# -------------------------------
def test_discount_price_normal():
    assert calculate_discounted_price(1000, 10) == 900

def test_discount_zero():
    assert calculate_discounted_price(500, 0) == 500

def test_discount_invalid():
    with pytest.raises(ValueError):
        calculate_discounted_price(-100, 10)

# -------------------------------
# Tests for is_course_full
# -------------------------------
def test_course_full_true():
    assert is_course_full(100, 100) is True

def test_course_full_false():
    assert is_course_full(50, 100) is False

def test_course_full_invalid():
    with pytest.raises(ValueError):
        is_course_full(-1, 50)

# -------------------------------
# Tests for get_course_level
# -------------------------------
@pytest.mark.parametrize("duration,level", [
    (1, "Beginner"),
    (3, "Intermediate"),
    (6, "Advanced")
])
def test_course_levels(duration, level):
    assert get_course_level(duration) == level

def test_course_level_invalid():
    with pytest.raises(ValueError):
        get_course_level(-3)
