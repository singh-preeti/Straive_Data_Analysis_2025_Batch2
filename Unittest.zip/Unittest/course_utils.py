# course_utils.py

def calculate_discounted_price(price, discount_percent):
    """Returns discounted price after applying percentage discount."""
    if price < 0 or discount_percent < 0:
        raise ValueError("Price and discount must be non-negative")
    return price - (price * discount_percent / 100)


def is_course_full(enrolled, capacity):
    """Returns True if course is full else False."""
    if enrolled < 0 or capacity <= 0:
        raise ValueError("Invalid enrolled or capacity values")
    return enrolled >= capacity


def get_course_level(duration_hours):
    """Categorizes course level based on duration."""
    if duration_hours < 0:
        raise ValueError("Duration cannot be negative")
    if duration_hours < 2:
        return "Beginner"
    elif 2 <= duration_hours <= 5:
        return "Intermediate"
    else:
        return "Advanced"
