import unittest
from udemy_util import (
    apply_tax,
    enroll_student,
    get_course_tags,
    get_course_metadata,
    divide_students
)

class TestUdemyUtils(unittest.TestCase):

    # 1. assert (basic assert)
    def test_basic_assert(self):
        result = 2 + 2
        assert result == 4

    # 2. assertEqual
    def test_apply_tax(self):
        self.assertEqual(apply_tax(100, 0.18), 118)

    # 3. assertTrue / assertFalse
    def test_enroll_student_true_false(self):
        course = {"students": []}
        updated = enroll_student(course, "Ravi")
        self.assertTrue("Ravi" in updated["students"])
        self.assertFalse("John" in updated["students"])

    # 4. assertRaises
    def test_apply_tax_invalid(self):
        with self.assertRaises(ValueError):
            apply_tax(-100, 0.18)

    # 5. assertIn / assertNotIn
    def test_course_tags(self):
        tags = get_course_tags("Python Basics")
        self.assertIn("python", tags)
        self.assertNotIn("react", tags)

    # 6. assertAlmostEqual
    def test_discount_almost_equal(self):
        # floating point example
        self.assertAlmostEqual(10 / 3, 3.333, places=3)

    # 7. assertDictEqual
    def test_course_metadata(self):
        expected = {
            "title": "Python Basics",
            "price": 499.99,
            "duration": 4.5
        }
        self.assertDictEqual(get_course_metadata(), expected)

    # 8. assertRaisesRegex
    def test_course_not_found(self):
        with self.assertRaisesRegex(KeyError, "Course 'Java' not found"):
            get_course_tags("Java")

    # Additional example: ZeroDivisionError
    def test_divide_students(self):
        with self.assertRaises(ZeroDivisionError):
            divide_students(50, 0)


if __name__ == "__main__":
    unittest.main()
