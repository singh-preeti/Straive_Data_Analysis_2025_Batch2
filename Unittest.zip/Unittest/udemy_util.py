# udemy_utils.py

def apply_tax(price, tax_rate):
    """Returns price after adding tax."""
    if price < 0:
        raise ValueError("Price cannot be negative")
    return price * (1 + tax_rate)


def enroll_student(course, student):
    """Adds student to course student list if not present."""
    if "students" not in course:
        course["students"] = []

    if student not in course["students"]:
        course["students"].append(student)

    return course


def get_course_tags(course_name):
    """Return sample tags for a course."""
    tags = {
        "Python Basics": ["python", "beginner", "coding"],
        "AI Essentials": ["ai", "ml", "technology"]
    }
    if course_name not in tags:
        raise KeyError(f"Course '{course_name}' not found")

    return tags[course_name]


def get_course_metadata():
    """Return metadata dictionary."""
    return {
        "title": "Python Basics",
        "price": 499.99,
        "duration": 4.5
    }


def divide_students(total_students, groups):
    """Divides students into groups; raises error for zero groups."""
    if groups == 0:
        raise ZeroDivisionError("Groups cannot be zero")
    return total_students / groups
