from flask_restful import Resource
from flask import request
import sqlite3
import json

# ------------------------------------------------
# SQLite Connection Function
# ------------------------------------------------
def get_db_connection():
    try:
        conn = sqlite3.connect("emp.db")  # DB file name
        conn.row_factory = sqlite3.Row  # Enables dict-like cursor results
        return conn
    except Exception as e:
        raise Exception(f"Database connection failed: {str(e)}")


# ------------------------------------------------
# Ensure TABLE exists (Optional)
# ------------------------------------------------
def create_books_table():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS books (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL
        )
        """
    )
    conn.commit()
    conn.close()

# Automatically create table at import
create_books_table()


# ------------------------------------------------
# GET ALL BOOKS
# ------------------------------------------------
class BooksGETResource(Resource):
    def get(self):
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM books")
            rows = cursor.fetchall()

            # Convert SQLite rows to dict
            results = [dict(row) for row in rows]

            return results, 200
        except Exception as e:
            return {"error": str(e)}, 500
        finally:
            try:
                conn.close()
            except:
                pass


# ------------------------------------------------
# GET BOOK BY ID
# ------------------------------------------------
class BookGETResource(Resource):
    def get(self, id):
        try:
            conn = get_db_connection()
            cursor = conn.cursor()

            cursor.execute("SELECT * FROM books WHERE id = ?", (id,))
            row = cursor.fetchone()

            if not row:
                return {"message": "Book not found"}, 404

            return dict(row), 200

        except Exception as e:
            return {"error": str(e)}, 500
        finally:
            try:
                conn.close()
            except:
                pass


# ------------------------------------------------
# ADD NEW BOOK
# ------------------------------------------------
class BookPOSTResource(Resource):
    def post(self):
        try:
            data = request.get_json(force=True)
            title = data.get("title")

            if not title:
                return {"message": "Title is required"}, 400

            conn = get_db_connection()
            cursor = conn.cursor()

            cursor.execute("INSERT INTO books (title) VALUES (?)", (title,))
            conn.commit()

            new_id = cursor.lastrowid
            return {"id": new_id, "title": title}, 201

        except Exception as e:
            return {"error": str(e)}, 500
        finally:
            try:
                conn.close()
            except:
                pass


# ------------------------------------------------
# UPDATE BOOK
# ------------------------------------------------
class BookPUTResource(Resource):
    def put(self, id):
        try:
            data = request.get_json(force=True)
            title = data.get("title")

            if not title:
                return {"message": "Title is required"}, 400

            conn = get_db_connection()
            cursor = conn.cursor()

            cursor.execute("UPDATE books SET title = ? WHERE id = ?", (title, id))
            conn.commit()

            if cursor.rowcount == 0:
                return {"message": "Book not found"}, 404

            return {"id": id, "title": title}, 200

        except Exception as e:
            return {"error": str(e)}, 500
        finally:
            try:
                conn.close()
            except:
                pass


# ------------------------------------------------
# DELETE BOOK
# ------------------------------------------------
class BookDELETEResource(Resource):
    def delete(self, id):
        try:
            conn = get_db_connection()
            cursor = conn.cursor()

            cursor.execute("DELETE FROM books WHERE id = ?", (id,))
            conn.commit()

            if cursor.rowcount == 0:
                return {"message": "Book not found"}, 404

            return {"message": "Deleted"}, 204

        except Exception as e:
            return {"error": str(e)}, 500
        finally:
            try:
                conn.close()
            except:
                pass
