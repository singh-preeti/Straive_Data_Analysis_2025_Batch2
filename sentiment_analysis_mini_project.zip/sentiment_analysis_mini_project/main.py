#
# from sentiment_model import load_model_and_vectorizer
#
# def main():
#     model, vectorizer = load_model_and_vectorizer()
#
#     print(" Real-Time Sentiment Analysis Console App ")
#     while True:
#         text = input("\nEnter a review (or type 'exit'): ")
#         if text.lower() == "exit":
#             break
#
#         vec = vectorizer.transform([text])
#         prediction = model.predict(vec)[0]
#         print(f"Predicted Sentiment: {prediction}")
#
# if __name__ == "__main__":
#     main()


#Worst experience ever. Total waste of money.




from sentiment_model import load_model_and_vectorizer

def main():
    model, vectorizer = load_model_and_vectorizer()

    print("=== Multi-Class Sentiment Analysis Console App ===")
    print("Classes: very_positive, positive, neutral, negative, very_negative")

    while True:
        text = input("\nEnter a review (or type 'exit'): ")
        if text.lower() == "exit":
            break

        vec = vectorizer.transform([text])
        prediction = model.predict(vec)[0]

        print(f"Predicted Sentiment: {prediction}")

if __name__ == "__main__":
    main()

