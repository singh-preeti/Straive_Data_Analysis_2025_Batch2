#
# import pandas as pd
#
# import pickle
#
# from sklearn.feature_extraction.text import TfidfVectorizer
# from sklearn.linear_model import LogisticRegression
#
#
# def train_model():
#     df = pd.read_csv("dummy_reviews.csv")
#
#     df['sentiment'] = df['rating'].apply(lambda x: 'positive' if x >= 4 else ('negative' if x <= 2 else 'neutral'))
#
#     X = df['review_text']
#     y = df['sentiment']
#
#     vectorizer = TfidfVectorizer()
#     X_vec = vectorizer.fit_transform(X)
#
#     model = LogisticRegression(max_iter=200)
#     model.fit(X_vec, y)
#
#     with open("sentiment_model.pkl", "wb") as f:
#         pickle.dump(model, f)
#
#     with open("vectorizer.pkl", "wb") as f:
#         pickle.dump(vectorizer, f)
#
#     print("Model & vectorizer saved successfully.")
#
# if __name__ == "__main__":
#     train_model()


import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
import pickle

def label_sentiment(r):
    if r == 5:
        return "very_positive"
    elif r == 4:
        return "positive"
    elif r == 3:
        return "neutral"
    elif r == 2:
        return "negative"
    else:
        return "very_negative"

def train_model():
    df = pd.read_csv("dummy_reviews.csv")

    # Convert ratings into 5-level sentiment classes
    df["sentiment"] = df["rating"].apply(label_sentiment)

    X = df["review_text"]
    y = df["sentiment"]

    # Vectorize
    vectorizer = TfidfVectorizer()
    X_vec = vectorizer.fit_transform(X)

    # Multi-class logistic regression
    model = LogisticRegression(max_iter=300, multi_class='ovr')
    model.fit(X_vec, y)

    # Save model
    with open("sentiment_model.pkl", "wb") as f:
        pickle.dump(model, f)

    with open("vectorizer.pkl", "wb") as f:
        pickle.dump(vectorizer, f)

    print("Multi-class model trained & saved successfully!")

if __name__ == "__main__":
    train_model()
