
from flask import Flask
from controllers.customer_controller import customer_bp
from controllers.account_controller import account_bp
from controllers.transaction_controller import transaction_bp

app = Flask(__name__)
app.register_blueprint(customer_bp)
app.register_blueprint(account_bp)
app.register_blueprint(transaction_bp)

if __name__ == "__main__":
    app.run(debug=True)
