
from flask import Blueprint, request, jsonify
from db import get_db

customer_bp = Blueprint('customer_bp', __name__, url_prefix="/customers")

@customer_bp.route("", methods=["POST"])
def create_customer():
    data = request.json
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("INSERT INTO customers(name, email, phone) VALUES (?, ?, ?)",
                   (data.get("name"), data.get("email"), data.get("phone")))
    conn.commit()
    return jsonify({"message": "Customer created"}), 201
