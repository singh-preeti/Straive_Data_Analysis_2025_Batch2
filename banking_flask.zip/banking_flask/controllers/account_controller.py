
from flask import Blueprint, request, jsonify
from db import get_db

account_bp = Blueprint('account_bp', __name__, url_prefix="/accounts")

@account_bp.route("/<int:account_no>/deposit", methods=["POST"])
def deposit(account_no):
    data = request.json
    amount = data.get("amount")
    if amount <= 0:
        return jsonify({"error": "Invalid amount"}), 400
    conn = get_db()
    c=conn.cursor()
    c.execute("UPDATE accounts SET balance = balance + ? WHERE account_no=?", (amount, account_no))
    c.execute("INSERT INTO transactions(account_no, amount, type, description) VALUES (?, ?, ?, ?)",
              (account_no, amount, "credit", "Deposit"))
    conn.commit()
    return jsonify({"message":"Deposited"}),200
