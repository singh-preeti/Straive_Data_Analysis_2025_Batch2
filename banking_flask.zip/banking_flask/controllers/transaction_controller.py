
from flask import Blueprint, jsonify
from db import get_db

transaction_bp = Blueprint('transaction_bp', __name__, url_prefix="/transactions")

@transaction_bp.route("/<int:acc>", methods=["GET"])
def list_txn(acc):
    conn = get_db()
    c=conn.cursor()
    c.execute("SELECT * FROM transactions WHERE account_no=?", (acc,))
    rows=[dict(r) for r in c.fetchall()]
    return jsonify(rows)
