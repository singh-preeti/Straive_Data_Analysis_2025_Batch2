from flask import Flask, jsonify, request
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

users = [
    {"id": 1, "name": "Alice", "email": "alice@example.com"},
    {"id": 2, "name": "Bob", "email": "bob@example.com"}
]
books = [
    {"id": 1, "title": "Book A", "author": "Author A"},
    {"id": 2, "title": "Book B", "author": "Author B"}
]

# Users endpoints
@app.route('/api/users', methods=['GET'])
def get_users():
    return jsonify(users)

@app.route('/api/users/<int:id>', methods=['GET'])
def get_user(id):
    user = next((u for u in users if u['id']==id), None)
    if user:
        return jsonify(user)
    return jsonify({"error":"Not found"}),404

@app.route('/api/users', methods=['POST'])
def create_user():
    data = request.json
    new_id = max(u['id'] for u in users)+1 if users else 1
    user = {"id": new_id, **data}
    users.append(user)
    return jsonify(user),201

@app.route('/api/users/<int:id>', methods=['PUT'])
def update_user(id):
    user = next((u for u in users if u['id']==id), None)
    if not user:
        return jsonify({"error":"Not found"}),404
    data = request.json
    user.update(data)
    return jsonify(user)

@app.route('/api/users/<int:id>', methods=['DELETE'])
def delete_user(id):
    global users
    users = [u for u in users if u['id']!=id]
    return jsonify({"message":"Deleted"})

# Books endpoints
@app.route('/api/books', methods=['GET'])
def get_books():
    return jsonify(books)

@app.route('/api/books', methods=['POST'])
def create_book():
    data = request.json
    new_id = max(b['id'] for b in books)+1 if books else 1
    book = {"id": new_id, **data}
    books.append(book)
    return jsonify(book),201

if __name__ == "__main__":
    app.run(debug=True)
