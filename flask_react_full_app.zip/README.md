Full-stack Flask + React Application

------------------------
Backend:
------------------------
1. Navigate to backend folder:
   cd backend
2. Install dependencies:
   pip install -r requirements.txt
3. Run Flask server:
   python app.py
4. API runs at http://localhost:5000

------------------------
Frontend:
------------------------
1. Navigate to frontend folder:
   cd frontend
2. Install dependencies:
   npm install
3. Run React dev server:
   npm start
4. React app runs at http://localhost:3000

Note: Frontend uses Axios to call the Flask API at http://localhost:5000
