import axios from 'axios';

const API = axios.create({
  baseURL: process.env.REACT_APP_API_URL || 'http://localhost:5000'
});

// Users
export const getUsers = () => API.get('/api/users');
export const getUser = (id) => API.get(`/api/users/${id}`);
export const createUser = (payload) => API.post('/api/users', payload);
export const updateUser = (id, payload) => API.put(`/api/users/${id}`, payload);
export const deleteUser = (id) => API.delete(`/api/users/${id}`);

// Books (sample)
export const getBooks = () => API.get('/api/books');
export const createBook = (payload) => API.post('/api/books', payload);

export default API;
