import React from 'react';
import { Routes, Route, Link } from 'react-router-dom';
import UsersList from './pages/UsersList';
import UserForm from './pages/UserForm';
import UserDetails from './pages/UserDetails';
import BooksList from './pages/BooksList';
import BookForm from './pages/BookForm';
import { ToastContainer } from 'react-toastify';

function App() {
  return (
    <div style={{ maxWidth: 900, margin: '0 auto', padding: 20 }}>
      <header style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
        <h2>Flask + React Demo</h2>
        <nav style={{ marginLeft: 'auto' }}>
          <Link to="/">Users</Link> | <Link to="/books">Books</Link>
        </nav>
      </header>

      <main style={{ marginTop: 20 }}>
        <Routes>
          <Route path='/' element={<UsersList />} />
          <Route path='/users/new' element={<UserForm />} />
          <Route path='/users/:id' element={<UserDetails />} />
          <Route path='/users/:id/edit' element={<UserForm editMode />} />
          <Route path='/books' element={<BooksList />} />
          <Route path='/books/new' element={<BookForm />} />
        </Routes>
      </main>

      <ToastContainer position="top-right" />
    </div>
  );
}

export default App;
