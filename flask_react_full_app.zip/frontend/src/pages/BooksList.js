import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { getBooks } from '../services/api';
import { toast } from 'react-toastify';

export default function BooksList() {
  const [books, setBooks] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    (async () => {
      try {
        const res = await getBooks();
        setBooks(res.data || []);
      } catch (err) {
        toast.error('Failed to load books');
      }
    })();
  }, []);

  return (
    <div>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
        <h3>Books</h3>
        <button onClick={() => navigate('/books/new')}>+ New Book</button>
      </div>

      <ul>
        {books.map(b => <li key={b.id}>{b.title} — {b.author}</li>)}
      </ul>
    </div>
  );
}
