import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { createUser, getUser, updateUser } from '../services/api';
import { toast } from 'react-toastify';

export default function UserForm({ editMode }) {
  const { id } = useParams();
  const navigate = useNavigate();
  const [form, setForm] = useState({ name: '', email: '' });

  useEffect(() => {
    if (editMode && id) {
      (async () => {
        try {
          const res = await getUser(id);
          setForm(res.data || {});
        } catch (err) {
          toast.error('Failed to load user');
        }
      })();
    }
  }, [editMode, id]);

  const submit = async (e) => {
    e.preventDefault();
    try {
      if (editMode) {
        await updateUser(id, form);
        toast.success('Updated');
      } else {
        await createUser(form);
        toast.success('Created');
      }
      navigate('/');
    } catch (err) {
      toast.error('Save failed');
    }
  };

  return (
    <form onSubmit={submit}>
      <h3>{editMode ? 'Edit User' : 'New User'}</h3>
      <div>
        <label>Name</label><br />
        <input value={form.name} onChange={e => setForm({...form, name: e.target.value})} required />
      </div>
      <div>
        <label>Email</label><br />
        <input value={form.email} onChange={e => setForm({...form, email: e.target.value})} required />
      </div>
      <div style={{ marginTop: 10 }}>
        <button type="submit">{editMode ? 'Update' : 'Create'}</button>
        <button type="button" onClick={() => navigate(-1)} style={{ marginLeft: 8 }}>Cancel</button>
      </div>
    </form>
  );
}
