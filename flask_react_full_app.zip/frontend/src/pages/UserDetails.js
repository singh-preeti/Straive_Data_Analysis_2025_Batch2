import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { getUser } from '../services/api';
import { toast } from 'react-toastify';

export default function UserDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [user, setUser] = useState(null);

  useEffect(() => {
    (async () => {
      try {
        const res = await getUser(id);
        setUser(res.data);
      } catch (err) {
        toast.error('Failed to load user');
      }
    })();
  }, [id]);

  if (!user) return <div>Loading...</div>;

  return (
    <div>
      <h3>User #{user.id}</h3>
      <p><strong>Name:</strong> {user.name}</p>
      <p><strong>Email:</strong> {user.email}</p>
      <button onClick={() => navigate(-1)}>Back</button>
    </div>
  );
}
