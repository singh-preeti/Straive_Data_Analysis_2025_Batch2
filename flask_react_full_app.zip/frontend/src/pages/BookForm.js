import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { createBook } from '../services/api';
import { toast } from 'react-toastify';

export default function BookForm() {
  const [form, setForm] = useState({ title: '', author: '' });
  const navigate = useNavigate();

  const submit = async (e) => {
    e.preventDefault();
    try {
      await createBook(form);
      toast.success('Book created');
      navigate('/books');
    } catch (err) {
      toast.error('Create failed');
    }
  };

  return (
    <form onSubmit={submit}>
      <h3>New Book</h3>
      <div>
        <label>Title</label><br />
        <input value={form.title} onChange={e => setForm({...form, title: e.target.value})} required />
      </div>
      <div>
        <label>Author</label><br />
        <input value={form.author} onChange={e => setForm({...form, author: e.target.value})} required />
      </div>
      <div style={{ marginTop: 10 }}>
        <button type="submit">Create</button>
        <button type="button" onClick={() => navigate(-1)} style={{ marginLeft: 8 }}>Cancel</button>
      </div>
    </form>
  );
}
