React frontend for your Flask API (Users & Books)

How to use:
1. Extract the zip and move into the folder:
   cd react_frontend
2. Install dependencies:
   npm install
3. Start the dev server:
   npm start
4. The app expects your Flask backend to run at http://localhost:5000
   - If needed, change the base URL in src/services/api.js

Features included:
- Users: list, view, create, edit, delete
- Books: list, create (sample page scaffold included)
- Axios service layer
- React Router
- Toast notifications (react-toastify)
